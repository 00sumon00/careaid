<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<!--<![endif]-->
<!--<![endif]-->
<html lang="en">
<head>
    <title>Care Aid - Welcome</title>
    <meta charset="utf-8">
    <!-- Meta -->
    <meta name="keywords" content="" />
    <meta name="author" content="">
    <meta name="robots" content="" />
    <meta name="description" content="" />

    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://www.google.com/fonts#UsePlace:use/Collection:Droid+Serif:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <link href='https://www.google.com/fonts#UsePlace:use/Collection:Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>

    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Stylesheets -->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('front/js/bootstrap/bootstrap.min.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('front/js/mainmenu/menu.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/default.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/shortcodes.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('front/css/responsive-leyouts.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('front/js/masterslider/style/masterslider.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('front/js/masterslider/style/ms-staff-style.css')); ?>" type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/js/cubeportfolio/cubeportfolio.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/Simple-Line-Icons-Webfont/simple-line-icons.css')); ?>" media="screen" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/et-line-font/et-line-font.css')); ?>">
    <link href="<?php echo e(asset('front/js/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('front/js/tabs/assets/css/responsive-tabs.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('front/js/ytplayer/ytplayer.css')); ?>" />



    <!-- Remove the below comments to use your color option -->
    <!--<link rel="stylesheet" href="css/colors/lightblue.css" />-->
    <!--<link rel="stylesheet" href="css/colors/orange.css" />-->
    <!--<link rel="stylesheet" href="css/colors/green.css" />-->
    <!--<link rel="stylesheet" href="css/colors/pink.css" />-->
    <!--<link rel="stylesheet" href="css/colors/red.css" />-->
    <!--<link rel="stylesheet" href="css/colors/purple.css" />-->
    <!--<link rel="stylesheet" href="css/colors/bridge.css" />-->
    <!--<link rel="stylesheet" href="css/colors/yellow.css" />-->
    <!--<link rel="stylesheet" href="css/colors/violet.css" />-->
    <!--<link rel="stylesheet" href="css/colors/cyan.css" />-->
    <!--<link rel="stylesheet" href="css/colors/mossgreen.css" />-->

</head>

<body>
<div class="site_wrapper">

    <div id="header">
        <div class="container">
            <div class="navbar navbar-default yamm">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                    <a href="/" class="navbar-brand">
                        <img src="<?php echo e(asset('front/images/logo.png')); ?>" alt="logo"/></a>
                </div>
                <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
                    <ul class="nav two navbar-nav">
                        <li class="dropdown"> <a href="<?php echo e('/'); ?>" class="active">Home</a>

                        </li>

                        <li class="dropdown yamm-fw"><a href="/about-us" class="">About Us</a>

                        </li>


                        <li class="dropdown"> <a href="portfolio-three.html" class="dropdown-toggle">Products</a>
                            <ul class="dropdown-menu" role="menu">
                                <li> <a href="portfolio-one.html">Single Item</a> </li>
                                <li> <a href="portfolio-two.html">Portfolio Columns 2</a> </li>
                                <li> <a href="portfolio-three.html">Portfolio Columns 3</a> </li>
                                <li> <a href="portfolio-four.html">Portfolio Columns 4</a> </li>
                                <li> <a href="portfolio-five.html">Portfolio + Sidebar</a> </li>
                                <li> <a href="portfolio-six.html">Portfolio Full Width</a> </li>
                                <li> <a href="portfolio-seven.html">Portfolio Masonry</a> </li>
                                <li> <a href="portfolio-eight.html">Masonry Projects</a> </li>
                                <li> <a href="portfolio-nine.html">Slider Projects</a> </li>
                                <li class="dropdown-submenu mul"> <a tabindex="-1" href="#">Sub Menu + </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Menu Item 1</a></li>
                                        <li><a href="#">Menu Item 2</a></li>
                                        <li><a href="#">Menu Item 3</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown yamm-fw"> <a href="#" class="">Contacts</a>

                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <!-- masterslider -->
    <div class="master-slider ms-skin-default" id="masterslider">

        <!-- slide 1 -->
        <div class="ms-slide slide-1" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/004.jpg')); ?>" alt=""/>

































        </div>
        <!-- end slide 1 -->

        <!-- slide 2 -->
        <div class="ms-slide slide-2" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/005.jpg')); ?>" alt=""/>

            </div>
        <!-- end slide 2 -->

        <!-- slide 3 -->
        <div class="ms-slide slide-2" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/03.png')); ?>" alt=""/>

        </div>
        <!-- end slide 3 -->

    </div>
    <!-- end of masterslider -->
    <div class="clearfix"></div>

    <div class="clearfix"></div>




























































































































    <!--end section-->






























































































































    <section class="parallax-section12">
        <div class="section-overlay dark">
            <div class="container sec-tpadding-2 sec-bpadding-2">
                <div class="row">






                    <div class="col-md-6 text-center">
                        <h2 class="section-title-2 text-white ubuntu">About Our Company</h2>
                        <div class="title-line-8"></div>
                        <p class="text-white text-justify">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue .</p>
                    </div>
                    <!--end item-->

                    <div class="col-md-6">
                        <div class="videobgholder">
                            <div id="wrapper">
                                <div id="customElement">
                                    <div class="container-fluid nopadding">
                                        <div class="video-overlay bg-opacity-5">
                                            <div class="container video-toppadd video-bopadd">
                                                <div class="col-md-8 col-centered text-center">
                                                    <h2 class="text-white section-title ubuntu less-mar2 uppercase">Add Your Own</h2>
                                                    <h2 class="text-white section-title ubuntu uppercase">Youtube Video Backgrounds</h2>
                                                    <button id="togglePlay" class="command vbutton pause" onclick="jQuery('#video').YTPTogglePlay(changeLabel)">Pause</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a id="video" class="player" data-property="{videoURL:'CWqndeS1Iu0',containment:'#customElement', showControls:false, autoPlay:true, loop:true, vol:50, mute:true, startAt:90,  stopAt:109, opacity:1, addRaster:true, quality:'hd720', optimizeDisplay:true}">My video</a> </div>
                    </div>
                    <!--end item-->















                    <!--end item-->

                </div>
            </div>
        </div>
    </section>
    <!--end section-->
    <div class="clearfix"></div>


























































































    <!--end section -->
    <div class="clearfix"></div>












































































































    <!--end section -->





























































































































































































    <section class="section-copyrights sec-moreless-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12"> <span>Copyright © 2020 <a href="">CareAid</a> | All rights reserved.</span></div>
            </div>
        </div>
    </section>
    <!--end section-->
    <div class="clearfix"></div>

    <a href="#" class="scrollup custom"></a><!-- end scroll to top of the page-->

</div>
<!--end sitewraper-->


<!-- ========== Js files ========== -->

<script type="text/javascript" src="<?php echo e(asset('front/js/universal/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/ytplayer/jquery.mb.YTPlayer.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/ytplayer/elementvideo-custom.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/ytplayer/play-pause-btn.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/masterslider/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/masterslider/masterslider.min.js')); ?>"></script>
<script type="text/javascript">
    (function($) {
        "use strict";
        var slider = new MasterSlider();
        // adds Arrows navigation control to the slider.
        slider.control('arrows');
        slider.control('bullets');

        slider.setup('masterslider' , {
            width:1600,    // slider standard width
            height:650,   // slider standard height
            space:0,
            speed:45,
            layout:'fullwidth',
            loop:true,
            preload:0,
            autoplay:true,
            view:"parallaxMask"
        });

        var slider = new MasterSlider();
        slider.setup('masterslider2' , {
            loop:true,
            width:110,
            height:110,
            speed:20,
            view:'focus',
            preload:0,
            space:0,
            space:30,
            viewOptions:{centerSpace:1.6}
        });
        slider.control('arrows');
        slider.control('slideinfo',{insertTo:'#staff-info'});

    })(jQuery);
</script>
<script src="<?php echo e(asset('front/js/mainmenu/customeUI.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/mainmenu/jquery.sticky.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/cubeportfolio/jquery.cubeportfolio.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/cubeportfolio/main.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/owl-carousel/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/owl-carousel/custom.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/tabs/assets/js/responsive-tabs.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/tabs/smk-accordion.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('front/js/tabs/custom.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/scrolltotop/totop.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/progress-circle/jquery.knob.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/progress-circle/custom.js')); ?>"></script>

<script src="<?php echo e(asset('front/js/scripts/functions.js')); ?>" type="text/javascript"></script>
</body>
</html>
<?php /**PATH D:\Development\careaid\resources\views/front/index.blade.php ENDPATH**/ ?>