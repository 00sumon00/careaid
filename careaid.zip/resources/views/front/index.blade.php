<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<!--<![endif]-->
<!--<![endif]-->
<html lang="en">
<head>
    <title>Care Aid - Welcome</title>
    <meta charset="utf-8">
    <!-- Meta -->
    <meta name="keywords" content="" />
    <meta name="author" content="">
    <meta name="robots" content="" />
    <meta name="description" content="" />

    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://www.google.com/fonts#UsePlace:use/Collection:Droid+Serif:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <link href='https://www.google.com/fonts#UsePlace:use/Collection:Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>

    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Stylesheets -->
    <link rel="stylesheet" media="screen" href="{{asset('front/js/bootstrap/bootstrap.min.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('front/js/mainmenu/menu.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('front/css/default.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('front/css/shortcodes.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('front/css/font-awesome/css/font-awesome.min.css')}}">
    <link rel="stylesheet" media="screen" href="{{asset('front/css/responsive-leyouts.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('front/js/masterslider/style/masterslider.css')}}" />
    <link rel='stylesheet' href="{{asset('front/js/masterslider/style/ms-staff-style.css')}}" type='text/css'>
    <link rel="stylesheet" type="text/css" href="{{asset('front/js/cubeportfolio/cubeportfolio.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('front/css/Simple-Line-Icons-Webfont/simple-line-icons.css')}}" media="screen" />
    <link rel="stylesheet" href="{{asset('front/css/et-line-font/et-line-font.css')}}">
    <link href="{{asset('front/js/owl-carousel/owl.carousel.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('front/js/tabs/assets/css/responsive-tabs.css')}}" />
    <link rel="stylesheet" href="{{asset('front/js/ytplayer/ytplayer.css')}}" />



    <!-- Remove the below comments to use your color option -->
    <!--<link rel="stylesheet" href="css/colors/lightblue.css" />-->
    <!--<link rel="stylesheet" href="css/colors/orange.css" />-->
    <!--<link rel="stylesheet" href="css/colors/green.css" />-->
    <!--<link rel="stylesheet" href="css/colors/pink.css" />-->
    <!--<link rel="stylesheet" href="css/colors/red.css" />-->
    <!--<link rel="stylesheet" href="css/colors/purple.css" />-->
    <!--<link rel="stylesheet" href="css/colors/bridge.css" />-->
    <!--<link rel="stylesheet" href="css/colors/yellow.css" />-->
    <!--<link rel="stylesheet" href="css/colors/violet.css" />-->
    <!--<link rel="stylesheet" href="css/colors/cyan.css" />-->
    <!--<link rel="stylesheet" href="css/colors/mossgreen.css" />-->

</head>

<body>
<div class="site_wrapper">

    <div id="header">
        <div class="container">
            <div class="navbar navbar-default yamm">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                    <a href="/" class="navbar-brand">
                        <img src="{{asset('front/images/logo.png')}}" alt="logo"/></a>
                </div>
                <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
                    <ul class="nav two navbar-nav">
                        <li class="dropdown"> <a href="{{'/'}}" class="active">Home</a>

                        </li>

                        <li class="dropdown yamm-fw"><a href="/about-us" class="">About Us</a>

                        </li>


                        <li class="dropdown"> <a href="portfolio-three.html" class="dropdown-toggle">Products</a>
                            <ul class="dropdown-menu" role="menu">
                                <li> <a href="portfolio-one.html">Single Item</a> </li>
                                <li> <a href="portfolio-two.html">Portfolio Columns 2</a> </li>
                                <li> <a href="portfolio-three.html">Portfolio Columns 3</a> </li>
                                <li> <a href="portfolio-four.html">Portfolio Columns 4</a> </li>
                                <li> <a href="portfolio-five.html">Portfolio + Sidebar</a> </li>
                                <li> <a href="portfolio-six.html">Portfolio Full Width</a> </li>
                                <li> <a href="portfolio-seven.html">Portfolio Masonry</a> </li>
                                <li> <a href="portfolio-eight.html">Masonry Projects</a> </li>
                                <li> <a href="portfolio-nine.html">Slider Projects</a> </li>
                                <li class="dropdown-submenu mul"> <a tabindex="-1" href="#">Sub Menu + </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Menu Item 1</a></li>
                                        <li><a href="#">Menu Item 2</a></li>
                                        <li><a href="#">Menu Item 3</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown yamm-fw"> <a href="#" class="">Contacts</a>

                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <!-- masterslider -->
    <div class="master-slider ms-skin-default" id="masterslider">

        <!-- slide 1 -->
        <div class="ms-slide slide-1" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/004.jpg')}}" alt=""/>

{{--            <h3 class="ms-layer text10"--}}
{{--                style="left: 230px;top: 200px;"--}}
{{--                data-type="text"--}}
{{--                data-delay="500"--}}
{{--                data-ease="easeOutExpo"--}}
{{--                data-duration="1230"--}}
{{--                data-effect="scale(1.5,1.6)"> We Help you to</h3>--}}

{{--            <h3 class="ms-layer text11"--}}
{{--                style="left: 230px;top: 245px;"--}}
{{--                data-type="text"--}}
{{--                data-delay="1000"--}}
{{--                data-ease="easeOutExpo"--}}
{{--                data-duration="1230"--}}
{{--                data-effect="scale(1.5,1.6)"> grow your business</h3>--}}

{{--            <a class="ms-layer sbut1"--}}
{{--               style="left: 230px; top: 360px;"--}}
{{--               data-type="text"--}}
{{--               data-delay="2000"--}}
{{--               data-ease="easeOutExpo"--}}
{{--               data-duration="1200"--}}
{{--               data-effect="scale(1.5,1.6)"> Read More </a>--}}

{{--            <a class="ms-layer sbut5"--}}
{{--               style="left: 390px; top: 360px;"--}}
{{--               data-type="text"--}}
{{--               data-delay="2500"--}}
{{--               data-ease="easeOutExpo"--}}
{{--               data-duration="1200"--}}
{{--               data-effect="scale(1.5,1.6)"> Purchase now ! </a>--}}

        </div>
        <!-- end slide 1 -->

        <!-- slide 2 -->
        <div class="ms-slide slide-2" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/005.jpg')}}" alt=""/>

            </div>
        <!-- end slide 2 -->

        <!-- slide 3 -->
        <div class="ms-slide slide-2" data-delay="9">
            <div class="slide-pattern"></div>
            <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/03.png')}}" alt=""/>

        </div>
        <!-- end slide 3 -->

    </div>
    <!-- end of masterslider -->
    <div class="clearfix"></div>

    <div class="clearfix"></div>

{{--    <section class="sec-padding">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-md-4">--}}
{{--                    <div class="feature-box15 bmargin">--}}
{{--                        <div class="image-holder"><img src="http://placehold.it/450x250" alt="" class="img-responsive"/></div>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <br/>--}}
{{--                        <h4 class="ubuntu">Our History</h4>--}}
{{--                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commodo augue Aliquam ornare.</p>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-4">--}}
{{--                    <div class="feature-box15 active bmargin">--}}
{{--                        <div class="image-holder"><img src="http://placehold.it/450x250" alt="" class="img-responsive"/></div>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <br/>--}}
{{--                        <h4 class="ubuntu">Our Mission</h4>--}}
{{--                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commodo augue Aliquam ornare.</p>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-4">--}}
{{--                    <div class="feature-box15 bmargin">--}}
{{--                        <div class="image-holder"><img src="http://placehold.it/450x250" alt="" class="img-responsive"/></div>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <br/>--}}
{{--                        <h4 class="ubuntu">What We Do</h4>--}}
{{--                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commodo augue Aliquam ornare.</p>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}

{{--    <section class="sec-padding section-pattren1">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xs-12 text-center">--}}
{{--                    <h2 class="section-title ubuntu">Our Services</h2>--}}
{{--                    <p class="sub-title">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent <span class="text-orange-2">mattis commodo</span> augue .</p>--}}
{{--                </div>--}}
{{--                <div class="col-md-4 col-sm-6">--}}
{{--                    <div class="feature-box16">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-desktop"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">UI Design</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-4 col-sm-6">--}}
{{--                    <div class="feature-box16 active">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-pencil"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">Graphic Design</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-4 col-sm-6">--}}
{{--                    <div class="feature-box16">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-strategy"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">Animation</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-4 col-sm-6 clearfix">--}}
{{--                    <div class="feature-box16">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-lightbulb"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">Web Development</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-4 col-sm-6">--}}
{{--                    <div class="feature-box16">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-basket"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">Branding</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-4 col-sm-6">--}}
{{--                    <div class="feature-box16">--}}
{{--                        <div class="iconbox-smedium round left white"><span class="icon-chat"></span></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h4 class="ubuntu">Excellent Support</h4>--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit amet justo Suspendisse et justo.</p>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
    <!--end section-->
{{--    <div class="clearfix"></div>--}}

{{--    <section class="sec-tpadding-2">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xs-12 text-center">--}}
{{--                    <h2 class="section-title ubuntu">Our Latest Works</h2>--}}
{{--                    <p class="sub-title">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent <span class="text-orange-2">mattis commodo</span> augue .</p>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <div class="container-fluid">--}}
{{--            <div class="row">--}}
{{--                <div class="demo-full-width">--}}
{{--                    <div id="grid-container" class="cbp">--}}
{{--                        <div class="cbp-item identity logos"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Suspendisse Imperdiet<br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Suspendisse Imperdiet </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item web-design"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Magna Tempus Urna<br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Magna Tempus Urna</div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item motion identity"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="World Clock Widget<br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Maecenas Sed </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item identity graphic"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Quisque Ornare <br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Quisque Ornare </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item motion logos"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Skateshop Website<br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Hendrerit Condimentum</div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item web-design"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Donec Dapibus Placerat <br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Donec Dapibus Placerat </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item identity motion"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Mauris non Quam ac eros<br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Mauris non Quam ac eros </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                        <div class="cbp-item web-design graphic"> <a href="http://placehold.it/800x600" class="cbp-caption cbp-lightbox" data-title="Vivamus Vulputate <br>by Codelayers">--}}
{{--                                <div class="cbp-caption-defaultWrap"> <img src="http://placehold.it/800x600" alt=""> </div>--}}
{{--                                <div class="cbp-caption-activeWrap">--}}
{{--                                    <div class="cbp-l-caption-alignLeft">--}}
{{--                                        <div class="cbp-l-caption-body">--}}
{{--                                            <div class="cbp-l-caption-title">Vivamus Vulputate </div>--}}
{{--                                            <div class="cbp-l-caption-desc">by Codelayers</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a> </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}

{{--    <section class="section-orange-2 section-less-padding">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-md-9">--}}
{{--                    <h3 class="text-white ubuntu">Useful Inner Pages</h3>--}}
{{--                    <p class="text-white">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue Aliquam ornare.</p>--}}
{{--                </div>--}}
{{--                <div class="col-md-3">--}}
{{--                    <div class="margin-top2"></div>--}}
{{--                    <a class="btn btn-border white-2 btn-large pull-right" href="#">Read more</a> </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}
    <section class="parallax-section12">
        <div class="section-overlay dark">
            <div class="container sec-tpadding-2 sec-bpadding-2">
                <div class="row">
{{--                    <div class="col-xs-12 text-center">--}}
{{--                        <h2 class="section-title-2 text-white ubuntu">About Our Company</h2>--}}
{{--                        <div class="title-line-8"></div>--}}
{{--                        <p class="sub-title">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue .</p>--}}
{{--                    </div>--}}
{{--                    <div class="clearfix"></div>--}}
                    <div class="col-md-6 text-center">
                        <h2 class="section-title-2 text-white ubuntu">About Our Company</h2>
                        <div class="title-line-8"></div>
                        <p class="text-white text-justify">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue . Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent mattis commodo augue .</p>
                    </div>
                    <!--end item-->

                    <div class="col-md-6">
                        <div class="videobgholder">
                            <div id="wrapper">
                                <div id="customElement">
                                    <div class="container-fluid nopadding">
                                        <div class="video-overlay bg-opacity-5">
                                            <div class="container video-toppadd video-bopadd">
                                                <div class="col-md-8 col-centered text-center">
                                                    <h2 class="text-white section-title ubuntu less-mar2 uppercase">Add Your Own</h2>
                                                    <h2 class="text-white section-title ubuntu uppercase">Youtube Video Backgrounds</h2>
                                                    <button id="togglePlay" class="command vbutton pause" onclick="jQuery('#video').YTPTogglePlay(changeLabel)">Pause</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a id="video" class="player" data-property="{videoURL:'CWqndeS1Iu0',containment:'#customElement', showControls:false, autoPlay:true, loop:true, vol:50, mute:true, startAt:90,  stopAt:109, opacity:1, addRaster:true, quality:'hd720', optimizeDisplay:true}">My video</a> </div>
                    </div>
                    <!--end item-->

{{--                    <div class="col-md-3">--}}
{{--                        <div class="demo">--}}
{{--                            <h5 class="text-white title">320 <span>Clients</span></h5>--}}
{{--                            <input class="knob" data-fgColor data-thickness="0.1" readonly value="85">--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <!--end item-->--}}

{{--                    <div class="col-md-3">--}}
{{--                        <div class="demo">--}}
{{--                            <h5 class="text-white title">148 <span>Awards</span></h5>--}}
{{--                            <input class="knob" data-fgColor data-thickness="0.1" readonly value="75">--}}
{{--                        </div>--}}
{{--                    </div>--}}
                    <!--end item-->

                </div>
            </div>
        </div>
    </section>
    <!--end section-->
    <div class="clearfix"></div>

{{--    <section>--}}
{{--        <!--end section-->--}}
{{--        <div class="clearfix"></div>--}}

{{--        <div class="videobgholder">--}}
{{--            <div id="wrapper">--}}
{{--                <div id="customElement">--}}
{{--                    <div class="container-fluid nopadding">--}}
{{--                        <div class="video-overlay bg-opacity-5">--}}
{{--                            <div class="container video-toppadd video-bopadd">--}}
{{--                                <div class="col-md-8 col-centered text-center">--}}
{{--                                    <h2 class="text-white section-title ubuntu less-mar2 uppercase">Add Your Own</h2>--}}
{{--                                    <h2 class="text-white section-title ubuntu uppercase">Youtube Video Backgrounds</h2>--}}
{{--                                    <button id="togglePlay" class="command vbutton pause" onclick="jQuery('#video').YTPTogglePlay(changeLabel)">Pause</button>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <a id="video" class="player" data-property="{videoURL:'CWqndeS1Iu0',containment:'#customElement', showControls:false, autoPlay:true, loop:true, vol:50, mute:true, startAt:90,  stopAt:109, opacity:1, addRaster:true, quality:'hd720', optimizeDisplay:true}">My video</a> </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}



{{--    <section class="sec-tpadding-2">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xs-12 text-center">--}}
{{--                    <h2 class="section-title ubuntu">Testimonials</h2>--}}
{{--                </div>--}}
{{--                <div class="clearfix"></div>--}}
{{--                <div class="col-md-12">--}}

{{--                    <!-- template -->--}}
{{--                    <div class="ms-staff-carousel ms-round">--}}
{{--                        <!-- masterslider -->--}}
{{--                        <div class="master-slider" id="masterslider2">--}}
{{--                            <div class="ms-slide"> <img src="../masterslider/style/blank.gif" data-src="http://placehold.it/110x110" alt="lorem ipsum dolor sit"/>--}}
{{--                                <div class="ms-info text-center">--}}
{{--                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, <span class="text-orange-2">sed diam nonummy nibh euismod</span> tincidunt. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt</p>--}}
{{--                                    <h5 class="less-mar1">Matthew</h5>--}}
{{--                                    <p>Mediatricks - Support</p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                            <div class="ms-slide"> <img src="../masterslider/style/blank.gif" data-src="http://placehold.it/110x110" alt="lorem ipsum dolor sit"/>--}}
{{--                                <div class="ms-info text-center">--}}
{{--                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, <span class="text-orange-2">sed diam nonummy nibh euismod</span> tincidunt. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt</p>--}}
{{--                                    <h5 class="less-mar1">Charlotte</h5>--}}
{{--                                    <p>Mediatricks - Support</p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                            <div class="ms-slide"> <img src="../masterslider/style/blank.gif" data-src="http://placehold.it/110x110" alt="lorem ipsum dolor sit"/>--}}
{{--                                <div class="ms-info text-center">--}}
{{--                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, <span class="text-orange-2">sed diam nonummy nibh euismod</span> tincidunt. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt</p>--}}
{{--                                    <h5 class="less-mar1">Olivia</h5>--}}
{{--                                    <p>Mediatricks - Support</p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <!-- end of masterslider -->--}}
{{--                        <div class="ms-staff-info" id="staff-info"> </div>--}}
{{--                    </div>--}}
{{--                    <!-- end of template -->--}}

{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}

{{--    <section class="section sec-padding">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-md-12">--}}
{{--                    <ul class="clientlogo-list two transparent">--}}
{{--                        <li><img src="http://placehold.it/140x100" alt=""/></li>--}}
{{--                        <li><img src="http://placehold.it/140x100" alt=""/></li>--}}
{{--                        <li><img src="http://placehold.it/140x100" alt=""/></li>--}}
{{--                        <li><img src="http://placehold.it/140x100" alt=""/></li>--}}
{{--                        <li class="last"><img src="http://placehold.it/140x100" alt=""/></li>--}}
{{--                    </ul>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
    <!--end section -->
    <div class="clearfix"></div>

{{--    <section class="sec-padding section-light">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xs-12 text-center">--}}
{{--                    <h2 class="section-title ubuntu">Meet Our Team</h2>--}}
{{--                    <p class="sub-title">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent <span class="text-orange-2">mattis commodo</span> augue .</p>--}}
{{--                </div>--}}
{{--                <div class="clearfix"></div>--}}

{{--                <div class="col-md-6 col-sm-12 bmargin">--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="img-holder"> <img src="http://placehold.it/450x550" alt="" class="img-responsive"/> </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="text-box white">--}}
{{--                            <div class="text-box-inner">--}}
{{--                                <h5 class="less-mar1">Mason</h5>--}}
{{--                                <span class="text-orange-2">Founder</span><br/>--}}
{{--                                <br/>--}}
{{--                                <p>Lorem ipsum dolor sit amet consectetuer sit et justo adipiscing. </p>--}}
{{--                                <br/>--}}
{{--                                <ul class="social-icons-2">--}}
{{--                                    <li class="first"><a href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                                    <li><a href="https://www.facebook.com/codelayers"><i class="fa fa-facebook"></i></a></li>--}}
{{--                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-6 col-sm-12 bmargin">--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="img-holder"> <img src="http://placehold.it/450x550" alt="" class="img-responsive"/> </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="text-box white">--}}
{{--                            <div class="text-box-inner min-height-1">--}}
{{--                                <h5 class="less-mar1">Isabella</h5>--}}
{{--                                <span class="text-orange-2">Manager</span><br/>--}}
{{--                                <br/>--}}
{{--                                <p>Lorem ipsum dolor sit amet consectetuer sit et justo adipiscing. </p>--}}
{{--                                <br/>--}}
{{--                                <ul class="social-icons-2">--}}
{{--                                    <li class="first"><a href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                                    <li><a href="https://www.facebook.com/codelayers"><i class="fa fa-facebook"></i></a></li>--}}
{{--                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="clearfix"></div>--}}
{{--                <br/>--}}
{{--                <br/>--}}
{{--                <div class="col-md-6 col-sm-12">--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="img-holder"> <img src="http://placehold.it/450x550" alt="" class="img-responsive"/> </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="text-box white">--}}
{{--                            <div class="text-box-inner min-height-1">--}}
{{--                                <h5 class="less-mar1">Charlotte</h5>--}}
{{--                                <span class="text-orange-2">Support</span><br/>--}}
{{--                                <br/>--}}
{{--                                <p>Lorem ipsum dolor sit amet consectetuer sit et justo adipiscing. </p>--}}
{{--                                <br/>--}}
{{--                                <ul class="social-icons-2">--}}
{{--                                    <li class="first"><a href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                                    <li><a href="https://www.facebook.com/codelayers"><i class="fa fa-facebook"></i></a></li>--}}
{{--                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-6 col-sm-12 bmargin">--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="img-holder"> <img src="http://placehold.it/450x550" alt="" class="img-responsive"/> </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-md-6 col-sm-6 col-xs-12">--}}
{{--                        <div class="text-box white">--}}
{{--                            <div class="text-box-inner min-height-1">--}}
{{--                                <h5 class="less-mar1">Benjamin</h5>--}}
{{--                                <span class="text-orange-2">Marketing</span><br/>--}}
{{--                                <br/>--}}
{{--                                <p>Lorem ipsum dolor sit amet consectetuer sit et justo adipiscing. </p>--}}
{{--                                <br/>--}}
{{--                                <ul class="social-icons-2">--}}
{{--                                    <li class="first"><a href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                                    <li><a href="https://www.facebook.com/codelayers"><i class="fa fa-facebook"></i></a></li>--}}
{{--                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
    <!--end section -->
{{--    <div class="clearfix"></div>--}}

{{--    <section class="sec-padding">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xs-12 text-center">--}}
{{--                    <h2 class="section-title ubuntu">Our Pricing</h2>--}}
{{--                    <p class="sub-title">Lorem ipsum dolor sit amet consectetuer adipiscing elit Suspendisse et justo Praesent <span class="text-orange-2">mattis commodo</span> augue .</p>--}}
{{--                </div>--}}
{{--                <div class="col-md-3 col-sm-6 text-center">--}}
{{--                    <div class="pricetable-holder3 bmargin">--}}
{{--                        <div class="inner-holder">--}}
{{--                            <h2 class="text-bold5 title ubuntu">Basic</h2>--}}
{{--                            <br/>--}}
{{--                            <div class="price-circle">--}}
{{--                                <div class="price"><sup>$</sup>9.99</div>--}}
{{--                                <i>/mo</i></div>--}}
{{--                            <br/>--}}
{{--                            <ul class="plan_features">--}}
{{--                                <li>1 GB Bandwidth</li>--}}
{{--                                <li class="highlight">256 MB Memory</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                            </ul>--}}
{{--                            <a class="btn btn-border light" href="#">Order now</a><br/>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-3 col-sm-6 text-center">--}}
{{--                    <div class="pricetable-holder3 bmargin">--}}
{{--                        <div class="inner-holder">--}}
{{--                            <h2 class="text-bold5 title ubuntu">Standard</h2>--}}
{{--                            <br/>--}}
{{--                            <div class="price-circle">--}}
{{--                                <div class="price"><sup>$</sup>19.9</div>--}}
{{--                                <i>/mo</i></div>--}}
{{--                            <br/>--}}
{{--                            <ul class="plan_features">--}}
{{--                                <li>1 GB Bandwidth</li>--}}
{{--                                <li class="highlight">256 MB Memory</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                            </ul>--}}
{{--                            <a class="btn btn-border light" href="#">Order now</a><br/>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-3 col-sm-6 text-center">--}}
{{--                    <div class="pricetable-holder3 active bmargin">--}}
{{--                        <div class="inner-holder">--}}
{{--                            <h2 class="text-bold5 title ubuntu">Premium</h2>--}}
{{--                            <br/>--}}
{{--                            <div class="price-circle">--}}
{{--                                <div class="price"><sup>$</sup>29.9</div>--}}
{{--                                <i>/mo</i></div>--}}
{{--                            <br/>--}}
{{--                            <ul class="plan_features">--}}
{{--                                <li>1 GB Bandwidth</li>--}}
{{--                                <li class="highlight">256 MB Memory</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                            </ul>--}}
{{--                            <a class="btn btn-border light" href="#">Order now</a><br/>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--                <div class="col-md-3 col-sm-6 text-center">--}}
{{--                    <div class="pricetable-holder3 bmargin">--}}
{{--                        <div class="inner-holder">--}}
{{--                            <h2 class="text-bold5 title ubuntu">Unlimited</h2>--}}
{{--                            <br/>--}}
{{--                            <div class="price-circle">--}}
{{--                                <div class="price"><sup>$</sup>39.9</div>--}}
{{--                                <i>/mo</i></div>--}}
{{--                            <br/>--}}
{{--                            <ul class="plan_features">--}}
{{--                                <li>1 GB Bandwidth</li>--}}
{{--                                <li class="highlight">256 MB Memory</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                                <li>Free Domain Name</li>--}}
{{--                            </ul>--}}
{{--                            <a class="btn btn-border light" href="#">Order now</a><br/>--}}
{{--                            <br/>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item -->--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}


{{--    <section class="section-dark sec-padding">--}}
{{--        <div class="container">--}}
{{--            <div class="row">--}}
{{--                <div class="col-md-3 clearfix">--}}
{{--                    <div class="item-holder">--}}
{{--                        <h4 class="uppercase footer-title less-mar3">Recent Posts</h4>--}}
{{--                        <div class="footer-title-bottomstrip"></div>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <div class="image-left"><img src="http://placehold.it/80x80" alt=""/></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h5 class="text-white less-mar3"><a href="#">Clean And Modern</a></h5>--}}
{{--                            <p>Lorem ipsum dolor sit</p>--}}
{{--                            <div class="footer-post-info"> <span>By John Doe</span><span>May 19</span> </div>--}}
{{--                        </div>--}}
{{--                        <div class="divider-line solid dark margin"></div>--}}
{{--                        <div class="image-left"><img src="http://placehold.it/80x80" alt=""/></div>--}}
{{--                        <div class="text-box-right">--}}
{{--                            <h5 class="text-white less-mar3"><a href="#">Layered PSD Files</a></h5>--}}
{{--                            <p>Lorem ipsum dolor sit</p>--}}
{{--                            <div class="footer-post-info"> <span>By John Doe</span><span>May 19</span> </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-3 clearfix">--}}
{{--                    <h4 class="uppercase footer-title less-mar3">useful links</h4>--}}
{{--                    <div class="clearfix"></div>--}}
{{--                    <div class="footer-title-bottomstrip"></div>--}}
{{--                    <ul class="usefull-links orange2">--}}
{{--                        <li><a href="#"><i class="fa fa-angle-right"></i> Placerat bibendum</a></li>--}}
{{--                        <li><a href="#"><i class="fa fa-angle-right"></i> Ullamcorper odio nec turpis</a></li>--}}
{{--                        <li><a href="#"><i class="fa fa-angle-right"></i> Aliquam porttitor vestibulum ipsum</a></li>--}}
{{--                        <li><a href="#"><i class="fa fa-angle-right"></i> Lobortis enim nec nisi</a></li>--}}
{{--                        <li class="last"><a href="#"><i class="fa fa-angle-right"></i> Placerat bibendum</a></li>--}}
{{--                    </ul>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-3 clearfix">--}}
{{--                    <div class="item-holder">--}}
{{--                        <h4 class="uppercase footer-title less-mar3">Newsletter</h4>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <div class="footer-title-bottomstrip"></div>--}}
{{--                        <div class="newsletter">--}}
{{--                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit sit et justo amet. Suspendisse et justo.</p>--}}
{{--                            <br />--}}
{{--                            <form method="get" action="index.html">--}}
{{--                                <input class="email_input" name="samplees" id="samplees" value="E-mail Address" onFocus="if(this.value == 'E-mail Address') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'E-mail Address';}" type="text">--}}
{{--                                <input name="" value="Go" class="input_submit orange2" type="submit">--}}
{{--                            </form>--}}
{{--                        </div>--}}
{{--                        <div class="margin-top3"></div>--}}
{{--                        <ul class="social-icons-3 white">--}}
{{--                            <li><a class="twitter" href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                            <li><a href="https://www.facebook.com/codelayers"><i class="fa fa-facebook"></i></a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>--}}
{{--                        </ul>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--                <div class="col-md-3 clearfix">--}}
{{--                    <div class="item-holder">--}}
{{--                        <h4 class="uppercase footer-title less-mar3">useful links</h4>--}}
{{--                        <div class="clearfix"></div>--}}
{{--                        <div class="footer-title-bottomstrip"></div>--}}
{{--                        <ul class="usefull-links orange2">--}}
{{--                            <li><a href="#"><i class="fa fa-angle-right"></i> Placerat bibendum</a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-angle-right"></i> Ullamcorper odio nec turpis</a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-angle-right"></i> Aliquam porttitor vestibulum ipsum</a></li>--}}
{{--                            <li><a href="#"><i class="fa fa-angle-right"></i> Lobortis enim nec nisi</a></li>--}}
{{--                            <li class="last"><a href="#"><i class="fa fa-angle-right"></i> Placerat bibendum</a></li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <!--end item-->--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!--end section-->--}}
{{--    <div class="clearfix"></div>--}}

    <section class="section-copyrights sec-moreless-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12"> <span>Copyright © 2020 <a href="">CareAid</a> | All rights reserved.</span></div>
            </div>
        </div>
    </section>
    <!--end section-->
    <div class="clearfix"></div>

    <a href="#" class="scrollup custom"></a><!-- end scroll to top of the page-->

</div>
<!--end sitewraper-->


<!-- ========== Js files ========== -->

<script type="text/javascript" src="{{asset('front/js/universal/jquery.js')}}"></script>
<script src="{{asset('front/js/bootstrap/bootstrap.min.js')}}" type="text/javascript"></script>
<script type="text/javascript" src="{{asset('front/js/ytplayer/jquery.mb.YTPlayer.js')}}"></script>
<script type="text/javascript" src="{{asset('front/js/ytplayer/elementvideo-custom.js')}}"></script>
<script type="text/javascript" src="{{asset('front/js/ytplayer/play-pause-btn.js')}}"></script>
<script src="{{asset('front/js/masterslider/jquery.easing.min.js')}}"></script>
<script src="{{asset('front/js/masterslider/masterslider.min.js')}}"></script>
<script type="text/javascript">
    (function($) {
        "use strict";
        var slider = new MasterSlider();
        // adds Arrows navigation control to the slider.
        slider.control('arrows');
        slider.control('bullets');

        slider.setup('masterslider' , {
            width:1600,    // slider standard width
            height:650,   // slider standard height
            space:0,
            speed:45,
            layout:'fullwidth',
            loop:true,
            preload:0,
            autoplay:true,
            view:"parallaxMask"
        });

        var slider = new MasterSlider();
        slider.setup('masterslider2' , {
            loop:true,
            width:110,
            height:110,
            speed:20,
            view:'focus',
            preload:0,
            space:0,
            space:30,
            viewOptions:{centerSpace:1.6}
        });
        slider.control('arrows');
        slider.control('slideinfo',{insertTo:'#staff-info'});

    })(jQuery);
</script>
<script src="{{asset('front/js/mainmenu/customeUI.js')}}"></script>
<script src="{{asset('front/js/mainmenu/jquery.sticky.js')}}"></script>
<script type="text/javascript" src="{{asset('front/js/cubeportfolio/jquery.cubeportfolio.min.js')}}"></script>
<script type="text/javascript" src="{{asset('front/js/cubeportfolio/main.js')}}"></script>
<script src="{{asset('front/js/owl-carousel/owl.carousel.js')}}"></script>
<script src="{{asset('front/js/owl-carousel/custom.js')}}"></script>
<script src="{{asset('front/js/tabs/assets/js/responsive-tabs.min.js')}}" type="text/javascript"></script>
<script type="text/javascript" src="{{asset('front/js/tabs/smk-accordion.js')}}"></script>
<script type="text/javascript" src="{{asset('front/js/tabs/custom.js')}}"></script>
<script src="{{asset('front/js/scrolltotop/totop.js')}}"></script>
<script src="{{asset('front/js/progress-circle/jquery.knob.js')}}"></script>
<script src="{{asset('front/js/progress-circle/custom.js')}}"></script>

<script src="{{asset('front/js/scripts/functions.js')}}" type="text/javascript"></script>
</body>
</html>
