<div class="master-slider ms-skin-default" id="masterslider">

    <!-- slide 1 -->
    <div class="ms-slide slide-1" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/004.jpg')}}" alt=""/>

        {{--            <h3 class="ms-layer text10"--}}
        {{--                style="left: 230px;top: 200px;"--}}
        {{--                data-type="text"--}}
        {{--                data-delay="500"--}}
        {{--                data-ease="easeOutExpo"--}}
        {{--                data-duration="1230"--}}
        {{--                data-effect="scale(1.5,1.6)"> We Help you to</h3>--}}

        {{--            <h3 class="ms-layer text11"--}}
        {{--                style="left: 230px;top: 245px;"--}}
        {{--                data-type="text"--}}
        {{--                data-delay="1000"--}}
        {{--                data-ease="easeOutExpo"--}}
        {{--                data-duration="1230"--}}
        {{--                data-effect="scale(1.5,1.6)"> grow your business</h3>--}}

        {{--            <a class="ms-layer sbut1"--}}
        {{--               style="left: 230px; top: 360px;"--}}
        {{--               data-type="text"--}}
        {{--               data-delay="2000"--}}
        {{--               data-ease="easeOutExpo"--}}
        {{--               data-duration="1200"--}}
        {{--               data-effect="scale(1.5,1.6)"> Read More </a>--}}

        {{--            <a class="ms-layer sbut5"--}}
        {{--               style="left: 390px; top: 360px;"--}}
        {{--               data-type="text"--}}
        {{--               data-delay="2500"--}}
        {{--               data-ease="easeOutExpo"--}}
        {{--               data-duration="1200"--}}
        {{--               data-effect="scale(1.5,1.6)"> Purchase now ! </a>--}}

    </div>
    <!-- end slide 1 -->

    <!-- slide 2 -->
    <div class="ms-slide slide-2" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/005.jpg')}}" alt=""/>

    </div>
    <!-- end slide 2 -->

    <!-- slide 3 -->
    <div class="ms-slide slide-2" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="{{asset('front/images/sliders/03.png')}}" alt=""/>

    </div>
    <!-- end slide 3 -->

</div>
