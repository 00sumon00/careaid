@extends('layouts.front_master')
@section('content')

     <section class="sec-padding">
        <div class="container">
            <div class="row">

                <div class="col-md-8 col-sm-12 col-xs-12">
                    <img src="{{asset('front/images/01.png')}}" alt="products" class=" img-responsive" style="max-width: 70% !important;"/>
                </div>
                <!--end item-->


                <div class="col-md-4 col-sm-12 col-xs-12" style="padding-top: 20px">
                    <h3 class="title_medium mt">SeptiCare Liquied Handwash</h3>
                        <p style="font-size: 24px;color: red">Active Silver Formula</p>
                        <p style="font-size: 18px;color: black">Germ Protection Handwash</p>
                        <p style="font-size: 14px;color: green">99.9% germ protection in just 10 seconds </p>
                        <br/>

                        <div class="clearfix"></div>
                        <br/>
{{--                        <ul class="social-icons-2">--}}
{{--                            <li><a class="twitter" href="https://twitter.com/codelayers"><i class="fa fa-twitter"></i></a></li>--}}
{{--                            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>--}}
{{--                            <li><a class="googleplus" href="#"><i class="fa fa-google-plus"></i></a></li>--}}
{{--                            <li><a class="in" href="#"><i class="fa fa-linkedin"></i></a></li>--}}
{{--                            <li><a class="dribble" href="#"><i class="fa fa-dribbble"></i></a></li>--}}
{{--                        </ul>--}}
{{--                        <div class="clearfix"></div>--}}
                        <br/>


                </div>

            </div>
        </div>
    </section>
    <!--end item -->
    <div class="clearfix"></div>



@endsection
