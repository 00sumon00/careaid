<div id="header">
    <div class="container">
        <div class="navbar navbar-default yamm">
            <div class="navbar-header">
                <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                <a href="/" class="navbar-brand">
                    <img src="<?php echo e(asset('front/images/logo.png')); ?>" alt="logo"/></a>
            </div>
            <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
                <ul class="nav two navbar-nav">
                    <li class="dropdown"> <a href="<?php echo e('/'); ?>" class="active">Home</a>

                    </li>

                    <li class="dropdown yamm-fw"><a href="/about-care-aid-ltd" class="">About Us</a>

                    </li>


                    <li class="dropdown"> <a href="portfolio-three.html" class="dropdown-toggle">Products</a>
                        <ul class="dropdown-menu" role="menu">
                            <li> <a href="/product-details">Handwash</a> </li>

                        </ul>
                    </li>
                    <li class="dropdown yamm-fw"> <a href="/contacts" class="">Contacts</a>

                    </li>

                </ul>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<?php /**PATH D:\Development\careaid\resources\views/front/header.blade.php ENDPATH**/ ?>