<?php $__env->startSection('content'); ?>

     <section class="sec-padding">
        <div class="container">
            <div class="row">

                <div class="col-md-8 col-sm-12 col-xs-12">
                    <img src="<?php echo e(asset('front/images/01.png')); ?>" alt="products" class=" img-responsive" style="max-width: 70% !important;"/>
                </div>
                <!--end item-->


                <div class="col-md-4 col-sm-12 col-xs-12" style="padding-top: 20px">
                    <h3 class="title_medium mt">SeptiCare Liquied Handwash</h3>
                        <p style="font-size: 24px;color: red">Active Silver Formula</p>
                        <p style="font-size: 18px;color: black">Germ Protection Handwash</p>
                        <p style="font-size: 14px;color: green">99.9% germ protection in just 10 seconds </p>
                        <br/>

                        <div class="clearfix"></div>
                        <br/>








                        <br/>


                </div>

            </div>
        </div>
    </section>
    <!--end item -->
    <div class="clearfix"></div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\careaid\resources\views/front/single_product.blade.php ENDPATH**/ ?>