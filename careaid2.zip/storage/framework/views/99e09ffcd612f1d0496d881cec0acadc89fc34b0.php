<div class="master-slider ms-skin-default" id="masterslider">

    <!-- slide 1 -->
    <div class="ms-slide slide-1" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/004.jpg')); ?>" alt=""/>

        
        
        
        
        
        
        

        
        
        
        
        
        
        

        
        
        
        
        
        
        

        
        
        
        
        
        
        

    </div>
    <!-- end slide 1 -->

    <!-- slide 2 -->
    <div class="ms-slide slide-2" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/005.jpg')); ?>" alt=""/>

    </div>
    <!-- end slide 2 -->

    <!-- slide 3 -->
    <div class="ms-slide slide-2" data-delay="9">
        <div class="slide-pattern"></div>
        <img src="js/masterslider/blank.gif" data-src="<?php echo e(asset('front/images/sliders/03.png')); ?>" alt=""/>

    </div>
    <!-- end slide 3 -->

</div>
<?php /**PATH D:\Development\careaid\resources\views/front/slider.blade.php ENDPATH**/ ?>